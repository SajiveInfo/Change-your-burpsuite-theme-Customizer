package burp;

import com.coreyd97.burpcustomizer.BurpCustomizer;

public class BurpExtender extends BurpCustomizer {

}
